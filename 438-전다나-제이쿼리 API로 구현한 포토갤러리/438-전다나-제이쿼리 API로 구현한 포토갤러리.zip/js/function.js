$(function() {
	const $mnu = $('.menu>li>a');
	const $img = $('.frame>a>img');
	$('footer>.frame').css('background-image', 'url(../images/th5.png)');

	for (let i = 0; i < $mnu.length; i++) {
		$mnu.eq(i).css({ backgroundImage: 'url(../images/th' + (i + 1) + '.png)' });
	}

	$mnu.click(function(evt) {
		evt.preventDefault();
		let imgSrc = $(this).attr('href');
		let altTxt = $(this).text();
		$img.attr({ src: imgSrc, alt: altTxt });
	});

	$mnu.mouseover(function() {
		$(this).css({ backgroundPosition: '0 -95px' });
	});
	$mnu.mouseout(function() {
		$(this).css({ backgroundPosition: '0 0' });
	});
});
